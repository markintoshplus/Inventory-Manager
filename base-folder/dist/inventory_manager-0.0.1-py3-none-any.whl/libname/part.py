class Part:
    def __init__(self, part_number, part_description, price):
        self.part_number = part_number
        self.part_description = part_description
        self.price = price